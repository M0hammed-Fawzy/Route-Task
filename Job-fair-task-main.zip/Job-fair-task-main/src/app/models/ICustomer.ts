
export type allCustomer = ICustomer[]

export interface ICustomer {
  id: string
  name: string
}